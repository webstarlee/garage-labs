<table cellspacing="0" cellpadding="0" border="0" style="color:#333;background:#fff;padding:0;margin:0;width:102%;font:15px/1.25em 'Helvetica Neue',Arial,Helvetica; margin-left:-6px; margin-top:-8px"> <tbody><tr width="100%"> <td valign="top" align="left" style="background:url(http://prestatairedigital.com/vendor/img/header.jpg);font:15px/1.25em 'Helvetica Neue',Arial,Helvetica"> <table style="border:none;padding:0 18px;margin:50px auto;width:90%"> <tbody> <tr width="100%" height="60"> <td valign="top" align="left" style="border-top-left-radius:4px;border-top-right-radius:4px;background:white url(https://ci5.googleusercontent.com/proxy/EX6LlCnBPhQ65bTTC5U1NL6rTNHBCnZ9p-zGZG5JBvcmB5SubDn_4qMuoJ-shd76zpYkmhtdzDgcSArG=s0-d-e1-ft#https://trello.com/images/gradient.png) bottom left repeat-x;padding:10px 18px;text-align:center"> <img height="35" src="http://prestatairedigital.com/vendor/img/logo-watermark.png" title="Trello" style="font-weight:bold;font-size:18px;color:#fff;vertical-align:top" class="CToWUd"> </td> </tr> <tr width="100%"> <td valign="top" align="left" style="background:#fff;padding:18px">

 <h1 style="font-size:20px;margin:16px 0;color:#333;text-align:center"> The new milestone {{$milestone->title}} was {{$milestone->action}}.</h1>

 <p style="font:15px/1.25em 'Helvetica Neue',Arial,Helvetica;color:#333;text-align:center"> 

 
 Pour accéder à votre fiche milestone, cliquez ici : </p>

 <div style="background:#f6f7f8;border-radius:3px"> <br>



 <p style="font:15px/1.25em 'Helvetica Neue',Arial,Helvetica;margin-bottom:0;text-align:center"> 
 

 <a href="{{ url("/projects/milestone/owner/management/$milestone->proposal_id") }}" style="border-radius:3px;background:#3aa54c;color:#fff;display:block;font-weight:700;font-size:16px;line-height:1.25em;margin:24px auto 6px;padding:10px 18px;text-decoration:none;width:180px" target="_blank"> Gérer mon projet </a> </p>

 <br><br> </div>

 <p style="font:14px/1.25em 'Helvetica Neue',Arial,Helvetica;color:#333"> <strong>Prestataire Digital</strong> est une plateforme de mise en relation, référençant les meilleurs freelances français. <a href="http://prestatairedigital.com" style="color:#306f9c;text-decoration:none;font-weight:bold" target="_blank">en savoir plus »</a> </p>

 </td>

 </tr>
 
 <tr ><td align=center><p style="font:14px/1.25em 'Helvetica Neue',Arial,Helvetica;color:white">
 <br/><br/><A HREF=http://prestatairedigital.com style="color:white;text-decoration:none;">GARAGELABS Digital</a> - 2016</p></td></tr>

 </tbody> </table> </td> </tr></tbody> </table>